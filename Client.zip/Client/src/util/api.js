﻿import { getAction, deleteAction, putAction, postAction } from './axios-api'

const login = (params) => postAction("/api/userLogin", params);
const reg = (params) => postAction("/api/userReg", params);
const getUserList = (params) => getAction("/api/getUsers", params);
const userEdit = (params) => putAction("/api/editUsers", params);
const userDel = (params) => deleteAction("/api/delUsers", params);



const goodList = (params) => getAction("/api/getProduct", params);
const goodAdd = (params) => postAction("/api/addProduct", params);
const goodEdit = (params) => putAction("/api/editProduct", params);
const goodDel = (params) => deleteAction("/api/delProduct", params);



export {
    login,
    reg,
    getUserList,
    userEdit,
    userDel,

    goodList,
    goodAdd,
    goodEdit,
    goodDel,
}
