<template>
    <div>
        <div :gutter="24">
            <el-col :span="7" :offset="8">
                <div class="grid-content bg-purple">
                    <el-card class="box-card" style="background:#92e0ea;color:#000;">
                        <div slot="header" class="clearfix">
                            <span>Sign in</span>
                        </div>
                        <div class="text item">
                            <el-form :model="ruleForm" status-icon :rules="rules" ref="ruleForm" label-width="120px" label-position="left" class="demo-ruleForm">
                                <el-form-item label="E-mail address" prop="user_email">
                                    <el-input v-model="ruleForm.user_email"></el-input>
                                </el-form-item>
                                <el-form-item label="Password" prop="user_password">
                                    <el-input type="password" v-model="ruleForm.user_password" autocomplete="off"></el-input>
                                </el-form-item>
                                <el-form-item>
                                    <el-button style="background:#3758cb;color:#000" type="primary" @click="submitForm('ruleForm')">Sign in</el-button>
                                    <el-button style="background:#3758cb;color:#000" type="text" @click="gotoReg()">Register</el-button>
                                </el-form-item>
                            </el-form>
                        </div>
                    </el-card>
                </div>
            </el-col>
        </div>
    </div>
</template>
<script>
import { login } from "./../../util/api";
export default {
    data() {
        return {
            ruleForm: {
                user_password: "",
                user_email: ""
            },
            rules: {
                user_password: [
                    { required: true, trigger: "blur", message: "Please input a password" },
                    { max: 6, message: "Six characters in length", trigger: "blur" }
                ],
                user_email: [
                    { required: true, message: "Please enter your email address", trigger: "blur" },
                    { type: "email", message: "Please enter the correct email address", trigger: "blur" }
                ]
            }
        };
    },
    methods: {
        submitForm(formName) {
            this.$refs[formName].validate((valid, val) => {
                if (valid) {
                    login(this.ruleForm).then(res => {
                        console.log("res --> ", res);
                        if (res.success) {
                            this.$message.success(res.msg);
                            localStorage.setItem("user", JSON.stringify(res.data));
                            if (res.data.is_admin == 0) {
                                this.$router.push("/goods");
                            } else {
                                this.$router.push("/user");
                            }
                        } else {
                            this.$message.error(res.msg);
                        }
                    });
                }
            });
        },
        gotoReg() {
            this.$router.push("/reg");
        },
        resetForm(formName) {
            this.$refs[formName].resetFields();
        }
    }
};
</script>
<style>
body {
    background: #000;
}
.el-form-item__label{
    color: #000;
    font-size: 14px;
}
</style>
<style scoped>
.box-card{
    color:#fff;
    *{
        color:#fff;
    }
}
.el-row {
    margin-bottom: 20px;

    &:last-child {
        margin-bottom: 0;
    }
}

.el-col {
    border-radius: 4px;
}

.bg-purple-dark {
    background: #99a9bf;
}

.bg-purple {
    background: #d3dce6;
}

.bg-purple-light {
    background: #e5e9f2;
}

.grid-content {
    border-radius: 4px;
    min-height: 36px;
    margin-top: 34%;
}

.row-bg {
    padding: 10px 0;
    background-color: #f9fafc;
}
</style>