<template>
    <div style="background:#000">
        <div :gutter="24">
            <el-col :span="7" :offset="8">
                <div class="grid-content bg-purple">
                    <el-card class="box-card" style="background:#92e0ea;color:#000;">
                        <div slot="header" class="clearfix">
                            <span>Register</span>
                        </div>
                        <div class="text item">
                            <el-form :model="ruleForm" status-icon :rules="rules" ref="ruleForm" label-width="120px" label-position="left" class="demo-ruleForm">
                                <el-form-item label="User name" prop="user_name">
                                    <el-input v-model="ruleForm.user_name"  placeholder="please name"></el-input>
                                </el-form-item>
                                <el-form-item label="Password" prop="user_password">
                                    <el-input type="password" v-model="ruleForm.user_password" autocomplete="off"  placeholder="please password"></el-input>
                                </el-form-item>
                                <el-form-item label="E-mail address" prop="user_email">
                                    <el-input v-model="ruleForm.user_email"  placeholder="please email"></el-input>
                                </el-form-item>
                                <el-form-item label="phone number" prop="user_tel">
                                    <el-input v-model="ruleForm.user_tel"  placeholder="please tel"></el-input>
                                </el-form-item>
                                <el-form-item label="Favourite List">
                                    <el-select v-model="ruleForm.user_favourites" multiple placeholder="please select" style="width:100%">
                                        <el-option v-for="(item,index) in favouritesArr" :key="index" :label="item" :value="index+1">
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                                <el-form-item>
                                    <el-button style="background:#3758cb;color:#000" type="primary" @click="submitForm('ruleForm')">Register</el-button>
                                    <el-button style="background:#3758cb;color:#000" type="text" @click="gotoLogin">To login</el-button>
                                </el-form-item>
                            </el-form>
                        </div>
                    </el-card>
                </div>
            </el-col>
        </div>
    </div>
</template>
<script>
import { reg } from "./../../util/api";
export default {
    name: 'reg',
    data() {
        return {
            favouritesArr: ['basketball', 'football', 'hiking', 'handball', 'swimming', 'bike'],

            ruleForm: {
                user_name: "",
                user_password: "",
                user_tel: "",
                user_email: "",
                user_favourites: '',
            },
            rules: {
                user_name: [
                    { required: true, trigger: "blur", message: "enter one user name" }
                ],
                user_tel: [
                    { required: true, trigger: "blur", message: "Please enter your cell phone number." },
                    { max: 11, message: "11-digit mobile phone number", trigger: "blur" }
                ],
                user_password: [
                    { required: true, trigger: "blur", message: "Please input a password" },
                    { max: 6, message: "Six characters in length", trigger: "blur" }
                ],
                user_email: [
                    { required: true, message: "Please enter your email address", trigger: "blur" },
                    { type: "email", message: "Please enter the correct email address", trigger: "blur" }
                ]
            }
        };
    },
    methods: {
        gotoLogin() {
            this.$router.push("/");
        },
        submitForm(formName) {
            this.$refs[formName].validate((valid, val) => {
                if (valid) {
                    this.ruleForm.user_favourites = this.ruleForm.user_favourites.join(',')
		    this.ruleForm.is_admin = 1;
                    reg(this.ruleForm).then(res => {
                        console.log("res --> ", res);
                        if (res.success) {
                            this.$message.success(res.msg);
                            this.$router.replace("/");
                        } else {
                            this.$message.error(res.msg);
                        }
                    });
                }
            });
        },
        resetForm(formName) {
            this.$refs[formName].resetFields();
        }
    }
};
</script>
<style>
body {
    background: #000;
}
.el-form-item__label{
    color: #000;
    font-size: 14px;
}
</style>
<style scoped>
.el-row {
    margin-bottom: 20px;

    &:last-child {
        margin-bottom: 0;
    }
}

.el-col {
    border-radius: 4px;
}

.bg-purple-dark {
    background: #99a9bf;
}

.bg-purple {
    background: #d3dce6;
}

.bg-purple-light {
    background: #e5e9f2;
}

.grid-content {
    border-radius: 4px;
    min-height: 36px;
    margin-top: 34%;
}

.row-bg {
    padding: 10px 0;
    background-color: #f9fafc;
}
</style>