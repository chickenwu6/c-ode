import Vue from 'vue';
import VueRouter from 'vue-router';
import login from './../views/login/login';
import reg from './../views/reg/reg';

import goods from './../views/goods/goods';
import user from './../views/user/user';

Vue.use(VueRouter);
let router = new VueRouter({
    routes: [
        { path: '/', name: "login", component: login },
        { path: '/login', name: "login", component: login },
        { path: '/reg', name: "reg", component: reg },
        {
            path: '/user',
            name: "user",
            component: user,
            meta: {
                requireAuth: true
            }
        },
        {
            path: '/goods',
            name: "goods",
            component: goods,
            meta: {
                requireAuth: true
            }
        },

        { path: "*", redirect: { name: "login" } }
    ]
});

router.beforeEach((to, from, next) => {
    var user = localStorage.getItem('user')
    if (to.matched.some(res => res.meta.requireAuth)) {
        if (!user) {
            next({
                path: '/login',
            })
        } else {
            next()
        }
    } else {
        next()
    }

});



export default router
