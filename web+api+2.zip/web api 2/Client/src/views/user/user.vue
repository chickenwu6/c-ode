﻿<template>
    <div>
        <div style="width: 95%;margin:0 auto;text-align:right">
            <el-button type="text" @click="loginout">Logout</el-button>
        </div>
        <div style="width: 95%;margin:0 auto;">
            <el-button type="text" @click="()=>{this.$router.push('/goods')}">Commodity management</el-button>
        </div>
        <div :gutter="24" >
            <el-col :span="22" :offset="1" style="    background: rgb(146, 224, 234);
    color: rgb(0, 0, 0);
">
                <div class="grid-content bg-purple" style="width: 90%;margin:0 auto;">
                    <el-breadcrumb separator-class="el-icon-arrow-right" style="margin:10px 0">
                        <el-breadcrumb-item>home page</el-breadcrumb-item>
                        <el-breadcrumb-item>user management</el-breadcrumb-item>
                    </el-breadcrumb>
                    <el-form :inline="true" class="demo-form-inline">
                        <el-form-item label="User name：">
                            <el-input v-model="user_name" size="small" placeholder="User name"></el-input>
                        </el-form-item>
                        <el-form-item>
                            <el-button size="small" type="primary" @click="onSubmit">Query</el-button>
                            <el-button size="small" @click="resetForm()">Reset</el-button>
                        </el-form-item>
                    </el-form>
                    <el-table class="mytable" :data="tableData.slice((currentPage-1)*pagesize,currentPage*pagesize)" border height="640">
                        <el-table-column fixed="left" label="operation" width="220">
                            <template slot-scope="scope">
                                <el-button type="text" @click="edit(scope.row)" size="small">edit</el-button>
                                <el-button type="text" @click="del(scope.row)" size="small">delete</el-button>
                            </template>
                        </el-table-column>
                        <el-table-column prop="user_name" label="User name" width="180"></el-table-column>
                        <el-table-column prop="user_password" label="Password" width="120"></el-table-column>
                        <el-table-column prop="user_email" label="E-mail address" width="280"></el-table-column>
                        <el-table-column prop="user_tel" label="phone number" width="200"></el-table-column>
                        <el-table-column prop="user_university" label="university" width="320"></el-table-column>
                        <el-table-column prop="user_favourites" label="Favourite List" width="320">
                            <template slot-scope="scope">
                                <span v-for="(item,index) in scope.row.user_favourites" :key="index">
                                    <el-tag>{{ favouritesArr[item-1] }}</el-tag>
                                    &nbsp;
                                </span>
                            </template>
                        </el-table-column>
                        <!-- <el-table-column prop="qq" label="what?" width="200"></el-table-column> -->
                        <el-table-column prop="is_admin" label="Administrator" width="120">
                            <template slot-scope="scope">{{scope.row.is_admin == 1 ? 'yes':'no'}}</template>
                        </el-table-column>
                    </el-table>
                    <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[5, 10, 20, 40]" :page-size="pagesize" layout="total, sizes, prev, pager, next, jumper" :total="tableData.length"></el-pagination>
                </div>
            </el-col>
        </div>
        <el-dialog title="Editor User" :visible.sync="dialogFormVisible" :close-on-click-modal="false">
            <el-form :model="ruleForm" status-icon :rules="rules" ref="ruleForm" label-width="120px" label-position="left" class="demo-ruleForm">
                <el-form-item label="User name" prop="user_name">
                    <el-input v-model="ruleForm.user_name"></el-input>
                </el-form-item>
                <el-form-item label="Password" prop="user_password">
                    <el-input type="password" v-model="ruleForm.user_password" autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item label="E-mail address" prop="user_email">
                    <el-input v-model="ruleForm.user_email"></el-input>
                </el-form-item>
                <el-form-item label="phone number" prop="user_tel">
                    <el-input v-model="ruleForm.user_tel"></el-input>
                </el-form-item>
                <el-form-item label="university" prop="user_university">
                    <el-input v-model="ruleForm.user_university"></el-input>
                </el-form-item>
                <!-- :label="item" -->
                <el-form-item label="Favourite List">
                    <el-select v-model="ruleForm.user_favourites" multiple placeholder="please select" style="width:100%">
                        <el-option v-for="(item,index) in favouritesArr" :key="index+1" :label="item" :value="index+1">
                        </el-option>
                    </el-select>
                </el-form-item>
                <!--
                <el-form-item label=".." prop="qq">
                    <el-input v-model="ruleForm.qq"></el-input>
                </el-form-item>
                 -->
                <el-form-item label="Administrator" prop="is_admin">
                    <el-select v-model="ruleForm.is_admin" placeholder="Administrator">
                        <el-option label="yes" :value="1"></el-option>
                        <el-option label="no" :value="0"></el-option>
                    </el-select>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">cancel</el-button>
                <el-button type="primary" @click="()=>updateUser()">assign</el-button>
            </div>
        </el-dialog>
    </div>
</template>
<script>
import {
    getUserList,
    userEdit,
    userDel
} from "./../../util/api";
export default {
    data() {
        return {
            user_name: "",
            tableData: [],
            favouritesArr: ['basketball', 'football', 'hiking', 'handball', 'swimming', 'bike'],

            currentPage: 1,
            pagesize: 10,

            dialogFormVisible: false,

            ruleForm: {
                is_admin: "",
                qq: "",
                user_email: "",
                user_name: "",
                user_password: "",
                user_tel: "",
                user_university: "",
                user_favourites: [],
                _id: ""
            },
            rules: {
                user_name: [{
                    required: true,
                    trigger: "blur",
                    message: "enter one user name"
                }],
                user_tel: [{
                        required: true,
                        trigger: "blur",
                        message: "Please enter your cell phone number."
                    },
                    {
                        max: 11,
                        message: "11-digit mobile phone number",
                        trigger: "blur"
                    }
                ],
                user_password: [{
                        required: true,
                        trigger: "blur",
                        message: "Please input a password"
                    },
                    {
                        max: 6,
                        message: "Six characters in length",
                        trigger: "blur"
                    }
                ],
                user_email: [{
                        required: true,
                        message: "Please enter your email address",
                        trigger: "blur"
                    },
                    {
                        type: "email",
                        message: "Please enter the correct email address",
                        trigger: "blur"
                    }
                ]
            }
        };
    },
    created() {
        this.getlist();
    },
    methods: {
        loginout() {
            this.$router.push('/');
            localStorage.clear()
        },
        getlist(obj) {
            getUserList(obj || "").then(res => {
                console.log("res --> ", res);

                if (res.success) {
                    this.tableData = res.data.map(item => {
                        item.user_favourites = item.user_favourites.split(',');
                        return item
                    });
                } else {
                    this.$message.error(res.msg);
                }
            });
        },
        onSubmit() {
            console.log("submit!");
            const {
                user_name
            } = this;
            this.getlist({
                user_name
            });
        },
        resetForm() {
            this.user_name = "";
            this.getlist();
        },
        edit(row) {
            console.log("row -->", row);
            this.dialogFormVisible = true;
            var newdata = JSON.parse(JSON.stringify(row))
            this.ruleForm = newdata;
            this.ruleForm.user_favourites = this.ruleForm.user_favourites.map(item => {
                return Number(item);
            })
        },
        del(row) {
            console.log(row);
            this.$confirm("This operation will permanently delete the file. Do you want to continue?", "Tips", {
                    confirmButtonText: "assign",
                    cancelButtonText: "cancel",
                    type: "warning"
                })
                .then(() => {
                    userDel(row).then(res => {
                        if (res.success) {
                            this.$message.success(res.msg);
                            this.getlist();
                        } else {
                            this.$message.error(res.msg);
                        }
                    });
                })
                .catch(() => {});
        },
        updateUser() {
            this.ruleForm.user_favourites = this.ruleForm.user_favourites.join(',')
            userEdit(this.ruleForm).then(res => {
                if (res.success) {
                    this.dialogFormVisible = false;
                    this.$message.success(res.msg);
                    this.getlist();
                } else {
                    this.dialogFormVisible = true;
                    this.$message.error(res.msg);
                }
            });
        },


        handleSizeChange: function(size) {
            this.pagesize = size;
            console.log(this.pagesize);
        },
        handleCurrentChange: function(currentPage) {
            this.currentPage = currentPage;
            console.log(this.currentPage);
        }
    }
};
</script>
<style>
body {
    background: #000;

}



.mytable table thead  tr th {
    background: #d5e4e7 !important;

}
.mytable table.el-table__body tbody  tr td {
    background: #e4e6d0 !important;

}

</style>
<style scoped>



.el-row {
    margin-bottom: 20px;

    &:last-child {
        margin-bottom: 0;
    }
}

.el-col {
    border-radius: 4px;
}

.bg-purple {
    padding: 10px;
}

.grid-content {
    border-radius: 4px;
    min-height: 36px;
}

.row-bg {
    padding: 10px 0;
    background-color: #f9fafc;
}
</style>