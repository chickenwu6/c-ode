﻿<template>
    <div>
        <div style="width: 95%;margin:0 auto;text-align:right">
            <el-button type="text" @click="loginout">Logout</el-button>
        </div>
        <div style="width: 95%;margin:0 auto;">
            <el-button v-if="isAdmin" type="text" @click="()=>{this.$router.push('/user')}">user management</el-button>
        </div>
        <div :gutter="24">
            <el-col :span="22" :offset="1" style="    background: rgb(146, 224, 234);
    color: rgb(0, 0, 0);
">
                <div class="grid-content bg-purple" style="width: 90%;margin:0 auto;">
                    <el-breadcrumb separator-class="el-icon-arrow-right" style="margin:10px 0">
                        <el-breadcrumb-item>home page</el-breadcrumb-item>
                        <el-breadcrumb-item>Commodity management</el-breadcrumb-item>
                    </el-breadcrumb>
                    <el-form :inline="true" class="demo-form-inline">
                        <el-form-item label="Commodity Name：">
                            <el-input v-model="good_name" size="small" placeholder="Commodity Name"></el-input>
                        </el-form-item>
                        <el-form-item>
                            <el-button size="small" type="primary" @click="onSubmit">Query</el-button>
                            <el-button size="small" @click="resetForm()">Reset</el-button>
                        </el-form-item>
                    </el-form>
                    <div style="margin:5px auto;">
                        <el-button type="primary" v-if="isAdmin" @click="addGood">New</el-button>
                    </div>
                    <el-table class="mytable" :data="tableData.slice((currentPage-1)*pagesize,currentPage*pagesize)" border height="640">
                        <el-table-column fixed="left" label="operation" width="220">
                            <template slot-scope="scope">
                                <el-button type="text" v-if="isAdmin" @click="edit(scope.row)" size="small">edit</el-button>
                                <el-button type="text" v-if="isAdmin" @click="del(scope.row)" size="small">delete</el-button>
                                <el-button type="text" @click="info(scope.row)" size="small">See</el-button>
                            </template>
                        </el-table-column>
                        <el-table-column prop="good_name" label="Name of commodity" width="180"></el-table-column>
                        <el-table-column prop="good_class" label="Categories of commodities" width="280">
                            <template slot-scope="scope">{{ getGoodClass(scope.row.good_class)}}</template>
                        </el-table-column>
                        <el-table-column prop="good_stocknum" label="Inventory Quantity of Goods" width="280"></el-table-column>
                        <el-table-column prop="good_issuenum" label="Quantity of goods on shelf" width="200"></el-table-column>
                        <el-table-column prop="good_price" label="commodity price" width="320"></el-table-column>
                        <el-table-column prop="good_batch" label="Commodity batches" width="320"></el-table-column>
                        <el-table-column prop="good_specs" label="Commodity specifications" width="220"></el-table-column>
                        <el-table-column prop="good_description" label="Commodity Description" width="320"></el-table-column>
                    </el-table>
                    <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage" :page-sizes="[5, 10, 20, 40]" :page-size="pagesize" layout="total, sizes, prev, pager, next, jumper" :total="tableData.length"></el-pagination>
                </div>
            </el-col>
        </div>
        <el-dialog :title="goodTitle" :visible.sync="dialogFormVisible">
            <el-form :model="ruleForm" status-icon :rules="rules" style="width:60%" ref="ruleForm" label-width="220px" label-position="left" class="demo-ruleForm">
                <el-form-item label="Name of commodity" prop="good_name">
                    <el-input v-model="ruleForm.good_name"></el-input>
                </el-form-item>
                <el-form-item label="Categories of commodities" prop="good_class">
                    <el-select v-model="ruleForm.good_class" placeholder="Categories of commodities">
                        <el-option label="Women\'s/Men\'s/Underwear" value="1"></el-option>
                        <el-option label="Household appliances/digital/mobile phones" value="2"></el-option>
                        <el-option label="Game/Animation/Film and Television" value="3"></el-option>
                        <el-option label="Automobile/Used Car" value="4"></el-option>
                        <el-option label="Learning/Books" value="5"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="Inventory Quantity of Goods" prop="good_stocknum">
                    <el-input type="number" v-model.number="ruleForm.good_stocknum"></el-input>
                </el-form-item>
                <el-form-item label="Quantity of goods on shelf" prop="good_issuenum">
                    <el-input type="number" v-model.number="ruleForm.good_issuenum"></el-input>
                </el-form-item>
                <el-form-item label="commodity price" prop="good_price">
                    <el-input type="number" v-model.number="ruleForm.good_price"></el-input>
                </el-form-item>
                <el-form-item label="Commodity batches" prop="good_batch">
                    <el-input v-model="ruleForm.good_batch"></el-input>
                </el-form-item>
                <el-form-item label="Commodity specifications" prop="good_specs">
                    <el-input v-model="ruleForm.good_specs"></el-input>
                </el-form-item>
                <el-form-item label="Commodity Description" prop="good_description">
                    <el-input v-model="ruleForm.good_description"></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">cancel</el-button>
                <el-button type="primary" @click="()=>updateUser()">assign</el-button>
            </div>
        </el-dialog>
        <el-dialog :title="goodTitle" :visible.sync="dialogInfoFormVisible">
            <el-form :model="ruleForm" status-icon style="width:60%" ref="ruleForm" label-width="220px" label-position="left" class="demo-ruleForm">
                <el-form-item label="Name of commodity" prop="good_name">
                    {{ruleForm.good_name }}
                </el-form-item>
                <el-form-item label="Categories of commodities" prop="good_class">
                    {{getGoodClass(ruleForm.good_class)}}
                </el-form-item>
                <el-form-item label="Inventory Quantity of Goods" prop="good_stocknum">
                    {{ruleForm.good_stocknum }}
                </el-form-item>
                <el-form-item label="Quantity of goods on shelf" prop="good_issuenum">
                    {{ruleForm.good_issuenum }}
                </el-form-item>
                <el-form-item label="commodity price" prop="good_price">
                    {{ruleForm.good_price }}
                </el-form-item>
                <el-form-item label="Commodity batches" prop="good_batch">
                    {{ruleForm.good_batch }}
                </el-form-item>
                <el-form-item label="Commodity specifications" prop="good_specs">
                    {{ruleForm.good_specs }}
                </el-form-item>
                <el-form-item label="Commodity Description" prop="good_description">
                    {{ruleForm.good_description }}
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogInfoFormVisible = false">cancel</el-button>
            </div>
        </el-dialog>
    </div>
</template>
<script>
import { goodAdd, goodList, goodEdit, goodDel } from "./../../util/api";
export default {
    data() {
        return {
            good_name: "",
            tableData: [],

            currentPage: 1,
            pagesize: 10,

            dialogFormVisible: false,

            dialogInfoFormVisible: false,

            ruleForm: {
                good_name: "",
                good_class: "",
                good_stocknum: "",
                good_issuenum: "",
                good_price: "",
                good_batch: "",
                good_specs: "",
                good_description: "",

            },
            rules: {
                good_name: [
                    { required: true, trigger: "blur", message: "Please enter the name of the product." }
                ],
                good_class: [
                    { required: true, trigger: "blur", message: "Please choose the commodity category." }
                ],
                good_stocknum: [
                    { required: true, trigger: "blur", message: "Please enter the quantity of goods in stock." }
                ],
                good_issuenum: [
                    { required: true, trigger: "blur", message: "Please enter the quantity of goods on shelf." }
                ],
                good_price: [
                    { required: true, trigger: "blur", message: "Please enter the commodity price." }
                ],
                good_batch: [
                    { required: true, trigger: "blur", message: "Please enter commodity batches" }
                ],

            },
            goodTitle: '',
        };
    },
    created() {
        this.getlist();
    },
    computed: {

        isAdmin() {
            var admin = localStorage.getItem('user') ? JSON.parse(localStorage.getItem('user')).is_admin : '';
            return admin ? true : false
        },
        getGoodClass: function(type) {
            return function(type) {
                var obj = {
                    1: 'Women\'s/Men\'s/Underwear',
                    2: 'Household appliances/digital/mobile phones',
                    3: 'Game/Animation/Film and Television',
                    4: 'Automobile/Used Car',
                    5: 'Learning/Books',
                }
                return obj[type]
            }
        }
    },
    methods: {
        loginout() {
            this.$router.push('/');
            localStorage.clear()
        },
        getlist(obj) {
            goodList(obj || "").then(res => {
                console.log("res --> ", res);

                if (res.success) {
                    this.tableData = res.data;
                } else {
                    this.$message.error(res.msg);
                }
            });
        },
        onSubmit() {
            console.log("submit!");
            const { good_name } = this;
            this.getlist({ good_name });
        },
        resetForm() {
            this.good_name = "";
            this.getlist();
        },
        addGood() {
            this.dialogFormVisible = true;
            this.ruleForm = {
                good_name: "",
                good_class: "",
                good_stocknum: "",
                good_issuenum: "",
                good_price: "",
                good_batch: "",
                good_specs: "",
                good_description: "",
            };
            this.goodTitle = 'New merchandise'
        },
        info(row) {
            this.dialogInfoFormVisible = true;
            this.ruleForm = row;
            this.goodTitle = 'Look the merchandise'
        },
        edit(row) {
            console.log("row-->", row);
            this.dialogFormVisible = true;
            this.ruleForm = row;
            this.goodTitle = 'Modifying Commodities'
        },
        del(row) {
            console.log(row);
            this.$confirm("This operation will permanently delete the file. Do you want to continue?", "Tips", {
                    confirmButtonText: "assign",
                    cancelButtonText: "cancel",
                    type: "warning"
                })
                .then(() => {
                    goodDel(row).then(res => {
                        if (res.success) {
                            this.$message.success(res.msg);
                            this.getlist();
                        } else {
                            this.$message.error(res.msg);
                        }
                    });
                })
                .catch(() => {});
        },
        updateUser() {
            this.ruleForm._id ?
                goodEdit(this.ruleForm).then(res => {
                    if (res.success) {
                        this.dialogFormVisible = false;
                        this.$message.success(res.msg);
                        this.getlist();
                    } else {
                        this.dialogFormVisible = true;
                        this.$message.error(res.msg);
                    }
                }) :
                goodAdd(this.ruleForm).then(res => {
                    if (res.success) {
                        this.dialogFormVisible = false;
                        this.$message.success(res.msg);
                        this.getlist();
                    } else {
                        this.dialogFormVisible = true;
                        this.$message.error(res.msg);
                    }
                })
        },

        handleSizeChange: function(size) {
            this.pagesize = size;
            console.log(this.pagesize);
        },
        handleCurrentChange: function(currentPage) {
            this.currentPage = currentPage;
            console.log(this.currentPage);
        }
    }
};
</script>
<style>
body {
    background: #000;
}


.mytable table thead  tr th {
    background: #d5e4e7 !important;

}
.mytable table.el-table__body tbody  tr td {
    background: #e4e6d0 !important;

}

</style>
<style scoped>
.el-row {
    margin-bottom: 20px;

    &:last-child {
        margin-bottom: 0;
    }
}

.el-col {
    border-radius: 4px;
}

.bg-purple {
    padding: 10px;
}

.grid-content {
    border-radius: 4px;
    min-height: 36px;
}

.row-bg {
    padding: 10px 0;
    background-color: #f9fafc;
}
</style>
