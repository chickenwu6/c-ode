import Vue from 'vue'
import axios from 'axios'
import { VueAxios } from './axios'
import { Message } from 'element-ui';


const service = axios.create({
    timeout: 6000,
})

const err = (error) => {
    if (error.response) {
        let data = error.response.data
        switch (error.response.status) {
            case 500:
                Message.error('Error')
                break
            case 404:
                Message.error('Lost')
                break
            default:
                Message.error(data.message)
                break
        }
    }
    return Promise.reject(error)
};

// request interceptor
service.interceptors.request.use(config => {
    return config
}, (error) => {
    return Promise.reject(error)
})

// response interceptor
service.interceptors.response.use((response) => {
    return response.data
}, err)

const installer = {
    vm: {},
    install(Vue, router = {}) {
        Vue.use(VueAxios, router, service)
    }
}

export {
    installer as VueAxios,
    service as axios
}