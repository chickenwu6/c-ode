<template>
    <div id="#app">
        <router-view :key="routerKey"></router-view>
    </div>
</template>
<script>
import bg from './assets/bg.jpg'
export default {
    data() {
        return {
            routerKey: this.$router.path,
            bg: bg
        };
    },
    mounted() {

    },
    methods: {}
};
</script>
<style>
* {
    margin: 0;
    padding: 0;
}
body{
    background: #eee;
}

#app {
    font-family: Helvetica, sans-serif;
    text-align: center;
}
</style>
