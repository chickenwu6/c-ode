// This file is created by egg-ts-helper@1.25.5
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportProduct = require('../../../app/model/product');
import ExportUser = require('../../../app/model/user');

declare module 'egg' {
  interface IModel {
    Product: ReturnType<typeof ExportProduct>;
    User: ReturnType<typeof ExportUser>;
  }
}
