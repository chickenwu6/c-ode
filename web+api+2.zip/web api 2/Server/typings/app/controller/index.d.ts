// This file is created by egg-ts-helper@1.25.5
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportHome = require('../../../app/controller/home');
import ExportProductController = require('../../../app/controller/productController');
import ExportUserController = require('../../../app/controller/userController');

declare module 'egg' {
  interface IController {
    home: ExportHome;
    productController: ExportProductController;
    userController: ExportUserController;
  }
}
