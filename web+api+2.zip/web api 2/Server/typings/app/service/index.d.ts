// This file is created by egg-ts-helper@1.25.5
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportProductServer = require('../../../app/service/productServer');
import ExportUserServer = require('../../../app/service/userServer');

declare module 'egg' {
  interface IService {
    productServer: ExportProductServer;
    userServer: ExportUserServer;
  }
}
