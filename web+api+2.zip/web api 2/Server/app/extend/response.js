
module.exports = {

    OK(ctx, msg, data) {
        ctx.body = {
            code: 200,
            msg: msg || 'Successful operation',
            success:true,
            ...data && { data: data },
        };
        ctx.status = 200;
    },

    FAIL(ctx, msg, data) {
        ctx.body = {
            code: 500,
            msg: msg || 'operation failed',
            success:false,
            ...data && { data: data },
        };
        ctx.status = 200;
    },

};
