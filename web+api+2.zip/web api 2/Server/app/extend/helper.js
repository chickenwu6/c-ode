var UUID = require('uuid');
module.exports = {

    getuuid() {
        return UUID.v1()
    },


};
