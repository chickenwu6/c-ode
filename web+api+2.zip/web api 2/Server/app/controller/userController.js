'use strict';

const Controller = require('egg').Controller;
var dayjs = require('dayjs');

class userController extends Controller {

    // Register
    async userReg() {
        const { ctx } = this;
        const body = ctx.request.body;
        let bodyData = {};
        ({ user_email: bodyData.user_email, user_tel: bodyData.user_tel } = body);

        if (!body.user_email || !body.user_tel) {
            ctx.response.FAIL(ctx, 'Parameters cannot be null')
            return;
        }

        const findUser = await ctx.service.userServer.findUser(bodyData);

        if (findUser.length) {
            ctx.response.FAIL(ctx, 'The account already exists')
        } else {
            const obj = new this.app.model.User({ ...body })
            const insertUser = await ctx.service.userServer.create(obj);
            insertUser && ctx.response.OK(ctx)
        }
    }

    // Login
    async userLogin() {
        const { ctx } = this;
        const body = ctx.request.body;
        let bodyData = {};
        ({ user_email: bodyData.user_email, user_password: bodyData.user_password } = body);

        if (!body.user_email || !body.user_password) {
            ctx.response.FAIL(ctx, 'Parameters cannot be null')
            return;
        }

        // check email
        const findUserByName = await ctx.service.userServer.findUser({ user_email: bodyData.user_email });
        if (findUserByName.length) {
            const findUser = await ctx.service.userServer.findUser(bodyData);

            if (findUser.length) {
                ctx.response.OK(ctx, 'Successful login', findUser[0])
            } else {
                ctx.response.FAIL(ctx, 'Password error, please contact the administrator to confirm the password')
            }

        } else {
            ctx.response.FAIL(ctx, 'This account does not exist. Please register.')
        }

    }

    
    async getUsers() {
        const { ctx } = this;
        const body = ctx.request.query;
        const query = {
            user_name: { $regex: new RegExp(body.user_name) }
        }
        const findUser = await ctx.service.userServer.findUser(body.user_name ? query : '');
        ctx.response.OK(ctx, 'Successful operation', findUser)
    }

    async editUsers() {
        const { ctx } = this;
        const body = ctx.request.body;
        let bodyData = {};
        ({ _id: bodyData._id, } = body);

        if (!body._id) {
            ctx.response.FAIL(ctx, 'User ID cannot be empty')
            return;
        }

        const updateData = await ctx.service.userServer.updateUser(body);
        if (updateData) {
            ctx.response.OK(ctx, 'Successful revision')
        } else {
            ctx.response.FAIL(ctx, 'The modification failed, please contact the administrator')
        }
    }
    async delUsers() {
        const { ctx } = this;
        const body = ctx.request.query;
        let bodyData = {};
        ({ _id: bodyData._id, } = body);

        if (!body._id) {
            ctx.response.FAIL(ctx, 'User ID cannot be empty')
            return;
        }

        const updateData = await ctx.service.userServer.delUser(body);
        if (updateData) {
            ctx.response.OK(ctx, 'Successful deletion')
        } else {
            ctx.response.FAIL(ctx, 'Delete failed, please contact administrator')
        }
    }

    async getUsersByName() {
        const { ctx } = this;
        const body = ctx.request.query;
        const findUser = await ctx.service.userServer.findUser(query);
        findUser.length && ctx.response.OK(ctx, 'Successful operation', findUser)
    }





}

module.exports = userController;
