'use strict';

const Controller = require('egg').Controller;
var dayjs = require('dayjs');

class productController extends Controller {

    // delete
    async delProduct() {
        const { ctx } = this;
        const body = ctx.request.query;
        const _id = body._id;
        const options = {
            _id: _id
        };
        if (!_id) {
            ctx.response.FAIL(ctx, 'Commodity ID cannot be empty')
            return;
        }
        const updateData = await ctx.service.productServer.delData(body);
        if (updateData) {
            ctx.response.OK(ctx, 'Successful deletion')
        } else {
            ctx.response.FAIL(ctx, 'Delete failed, please contact administrator')
        }

    }

    // add , edit
    async addProduct() {
        const { ctx } = this;
        const body = ctx.request.body;
        let bodyData = {};
        const ProductID = body.ProductID;
        ({
            good_name: bodyData.good_name,
            good_class: bodyData.good_class,
        } = ctx.request.body);

        if (!body.good_name || !body.good_class) {
            ctx.response.FAIL(ctx, 'Parameters cannot be null')
            return;
        }

        // create
        const findResult = await ctx.service.productServer.findData(bodyData);

        if (!findResult.length) {
            var obj = new this.app.model.Product({ ...body })
            const insertData = await ctx.service.productServer.createData(obj);
            insertData && ctx.response.OK(ctx, 'New Success')
        } else {
            ctx.response.FAIL(ctx, 'This product already exists. Please do not add it again.')
            return;
        }


    }

    async editProduct() {
        const { ctx } = this;
        const body = ctx.request.body;
        let bodyData = {};
        ({
            _id: bodyData._id,
        } = body);

        if (!body._id) {
            ctx.response.FAIL(ctx, 'Commodity ID cannot be empty')
            return;
        }

        const updateData = await ctx.service.productServer.updateData(body);
        if (updateData) {
            ctx.response.OK(ctx, 'Successful revision')
        } else {
            ctx.response.FAIL(ctx, 'The modification failed, please contact the administrator')
        }
    }

    // get info.
    async getProduct() {
        const { ctx } = this;
        const body = ctx.request.query;
        const query = {
            good_name: { $regex: new RegExp(body.good_name) }
        }
        const findResult = await ctx.service.productServer.findData(body.good_name ? query : '');
        ctx.response.OK(ctx, 'Successful operation', findResult)
    }

    
    async getProductInfo() {
        const { ctx } = this;
        const body = ctx.request.query;
        const obj = { ProductID: body.ProductID }
        const findResult = await ctx.service.productServer.findData(obj);
        findResult.length && ctx.response.OK(ctx, 'Successful operation', findResult)
    }

}

module.exports = productController;
