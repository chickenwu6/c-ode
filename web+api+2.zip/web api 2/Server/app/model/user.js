module.exports = app => {
    const mongoose = app.mongoose;
    const Schema = mongoose.Schema;
    const UserSchema = new Schema({
        user_name: { type: String, required: true, },
        user_password: { type: String, required: true, maxlength: 6 },
        user_email: { type: String, required: true, },
        user_tel: { type: String, required: true, maxlength: 11 },
        user_university: { type: String, default:''},
        user_favourites: { type: String },
        qq: { type: String,default:'' },
        is_admin: { type: Number, default: 0 },
    });
    return mongoose.model('User', UserSchema);
}
