module.exports = app => {
    const mongoose = app.mongoose
    const Schema = mongoose.Schema
    const ProductSchema = new Schema({
        good_name: { type: String, required: true, },
        good_class: { type: String, required: true, },
        good_stocknum: { type: Number, required: true, },
        good_issuenum: { type: Number, required: true, },
        good_price: { type: Number, required: true, },
        good_batch: { type: String, required: true, },
        good_specs: { type: String, default: '' },
        good_description: { type: String, default: '' },
    })
    return mongoose.model('Product', ProductSchema)
}
