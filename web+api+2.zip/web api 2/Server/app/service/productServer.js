const { Service } = require('egg');

class productServer extends Service {

    async findData(data) {
        const results = await this.app.model.Product.find(data || {});
        return results;
    }

    async createData(data) {
        const results = await data.save();
        return results;
    }

    async updateData(data) {
        const result = await this.app.model.Product.update({ _id: data._id }, data);
        return result.ok ? true : false;
    }

    async delData(data) {
        const results = await this.app.model.Product.remove({ _id: data._id });
        return results.ok ? true : false;
    }



}

module.exports = productServer
