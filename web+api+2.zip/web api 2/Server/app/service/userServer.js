const { Service } = require('egg');

class userService extends Service {

    async findUser(data) {
        const results = await this.app.model.User.find(data || {});
        return results;
    }

    async create(data) {
        const results = await data.save();
        return results;
    }

    async updateUser(data) {
        const results = await this.app.model.User.update({ _id: data._id }, data);
        return results.ok ? true : false;
    }

    async delUser(data) {
        const results = await this.app.model.User.remove({ _id: data._id });
        return results.ok ? true : false;
    }

}

module.exports = userService
