'use strict';


/**
 * @param {Egg.Application} app - egg application
 */
module.exports = app => {
    const { router, controller } = app;

    // Front Page
    router.get('/', controller.home.index);

    // Login / Register / Register
    router.get('/getUsers', controller.userController.getUsers);
    router.post('/userReg', controller.userController.userReg);
    router.post('/userLogin', controller.userController.userLogin);
    router.put('/editUsers', controller.userController.editUsers);
    router.del('/delUsers', controller.userController.delUsers);


     
    router.get('/getProduct',  controller.productController.getProduct);
    router.post('/addProduct',  controller.productController.addProduct);
    router.put('/editProduct',  controller.productController.editProduct);
    router.del('/delProduct',  controller.productController.delProduct);


};
